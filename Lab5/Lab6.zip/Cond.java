interface Cond {
  boolean eval();
  Cond neg();
}