package cs2030s.fp;

public class Lazy<T> /* implements Immutatorable<T> */ {
  private Constant<? extends T> init;
}