package cs2030s.fp;

public class Memo<T> extends Lazy<T> {
  private Actually<T> value;
}